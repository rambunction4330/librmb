#include "SwerveDrive.h"

namespace rmb {
template class rmb::SwerveDrive<4>;
}
